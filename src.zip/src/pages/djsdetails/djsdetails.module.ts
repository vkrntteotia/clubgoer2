import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DjsdetailsPage } from './djsdetails';

@NgModule({
  declarations: [
    DjsdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(DjsdetailsPage),
  ],
})
export class DjsdetailsPageModule {}
