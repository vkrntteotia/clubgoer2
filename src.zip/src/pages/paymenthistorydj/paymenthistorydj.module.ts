import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PaymenthistorydjPage } from './paymenthistorydj';

@NgModule({
  declarations: [
    PaymenthistorydjPage,
  ],
  imports: [
    IonicPageModule.forChild(PaymenthistorydjPage),
  ],
})
export class PaymenthistorydjPageModule {}
