import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OmniaclubeventdjPage } from './omniaclubeventdj';

@NgModule({
  declarations: [
    OmniaclubeventdjPage,
  ],
  imports: [
    IonicPageModule.forChild(OmniaclubeventdjPage),
  ],
})
export class OmniaclubeventdjPageModule {}
