import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TransactionhstrydjPage } from './transactionhstrydj';

@NgModule({
  declarations: [
    TransactionhstrydjPage,
  ],
  imports: [
    IonicPageModule.forChild(TransactionhstrydjPage),
  ],
})
export class TransactionhstrydjPageModule {}
