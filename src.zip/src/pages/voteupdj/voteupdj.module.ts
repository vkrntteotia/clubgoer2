import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VoteupdjPage } from './voteupdj';

@NgModule({
  declarations: [
    VoteupdjPage,
  ],
  imports: [
    IonicPageModule.forChild(VoteupdjPage),
  ],
})
export class VoteupdjPageModule {}
