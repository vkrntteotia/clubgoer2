import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditeventPage } from './editevent';

@NgModule({
  declarations: [
    EditeventPage,
  ],
  imports: [
    IonicPageModule.forChild(EditeventPage),
  ],
})
export class EditeventPageModule {}
