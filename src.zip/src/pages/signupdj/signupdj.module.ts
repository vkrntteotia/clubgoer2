import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignupdjPage } from './signupdj';

@NgModule({
  declarations: [
    SignupdjPage,
  ],
  imports: [
    IonicPageModule.forChild(SignupdjPage),
  ],
})
export class SignupdjPageModule {}
