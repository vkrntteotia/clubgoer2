import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SubscribedjPage } from './subscribedj';

@NgModule({
  declarations: [
    SubscribedjPage,
  ],
  imports: [
    IonicPageModule.forChild(SubscribedjPage),
  ],
})
export class SubscribedjPageModule {}
