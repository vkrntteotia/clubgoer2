import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NameofeventsdjPage } from './nameofeventsdj';

@NgModule({
  declarations: [
    NameofeventsdjPage,
  ],
  imports: [
    IonicPageModule.forChild(NameofeventsdjPage),
  ],
})
export class NameofeventsdjPageModule {}
