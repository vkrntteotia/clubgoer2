import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, AlertController, Events, MenuController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { HomePage } from '../pages/home/home';
import { ProfilePage } from '../pages/profile/profile';
import { DjslistPage } from '../pages/djslist/djslist';
import { TermsPage } from '../pages/terms/terms';
import { PrivacyPage } from '../pages/privacy/privacy';
import { Appsetting } from '../providers/appsetting';
import { VotelikePage } from '../pages/votelike/votelike';
import { HistoricalrequestsPage } from '../pages/historicalrequests/historicalrequests';
import { ChangepasswordPage } from '../pages/changepassword/changepassword';
import { TransactionhstrydjPage } from '../pages/transactionhstrydj/transactionhstrydj';
import { HelpdjPage } from '../pages/helpdj/helpdj';
import { LogindjPage } from '../pages/logindj/logindj';
import { LoginPage } from '../pages/login/login';
import { MembershipdetaildjPage } from '../pages/membershipdetaildj/membershipdetaildj';
import { ChangepassworddjPage } from '../pages/changepassworddj/changepassworddj';
import { SignindjPage } from '../pages/signindj/signindj';
import { EventsdjPage } from '../pages/eventsdj/eventsdj';
import { SubscribedjPage } from '../pages/subscribedj/subscribedj';
import { EditprofiledjPage } from '../pages/editprofiledj/editprofiledj';
import { NameofeventsdjPage } from '../pages/nameofeventsdj/nameofeventsdj';
import { TermsdjPage } from '../pages/termsdj/termsdj';

import * as moment from 'moment'
// import {StatusBar} from '@ionic-native/status-bar';
@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
  rootPage: any = SignindjPage;
  activePage: any;
  role;profile;
  pages: Array<{ title: string, component: any, icon: any }>;
  djmenu: Array<{ title: string, component: any, icon: any }>;

  constructor(
    public platform: Platform,
    public statusBar: StatusBar,
    public splashScreen: SplashScreen,
    public appsetting: Appsetting,
    private alertCtrl: AlertController,
    public events: Events,
    public menuCtrl: MenuController
  ) {
    
    platform.ready().then(() => {
      statusBar.overlaysWebView(true);
      
      statusBar.hide();

    });
  
    this.initializeApp();
    this.events.subscribe('role', data => {
      //console.log(data);
      //this.role = data;
      if (localStorage.getItem("USER_DATA")!=null) {   
        this.profile = JSON.parse(localStorage.getItem("USER_DATA"));
        console.log(this.profile);
      if (this.profile.role == 'clubgoer') {
        this.role="clubgoer";
        this.pages = [
          { title: 'Home', component: HomePage, icon: 'homecustom' },
          { title: 'My Profile', component: ProfilePage, icon: 'profile' },
          { title: 'Voteup Request', component: VotelikePage, icon: 'voteup' },
          { title: 'Djs List', component: DjslistPage, icon: 'djs' },
          { title: 'Historical Transactions', component: HistoricalrequestsPage, icon: 'historical' },
          { title: 'Terms and Conditions', component: TermsPage, icon: 'terms' },
          { title: 'Privacy Policy', component: PrivacyPage, icon: 'privacy' },
          { title: 'Change Password', component: ChangepasswordPage, icon: 'historical' },
          //{ title: 'Payment Info', component: PaymentinfoPage, icon: 'terms' },
          { title: 'Sign Out', component: null, icon: 'logout' },
        ];
        this.menuCtrl.enable(true, 'clubgoer');
      } else {
        this.role="dj";
        this.djmenu = [
          { title: 'Events', component: EventsdjPage, icon: 'eve' },
          { title: 'Edit Profile', component: EditprofiledjPage, icon: 'edi' },
          { title: 'Transaction History', component: TransactionhstrydjPage, icon: 'tra' },
          { title: 'Requests', component: NameofeventsdjPage, icon: 'req' },
          { title: 'Terms and Conditions', component: TermsdjPage, icon: 'ter' },
          { title: 'Billing', component: MembershipdetaildjPage, icon: 'logo-usd' },
          { title: 'Help', component: HelpdjPage, icon: 'hel' },];
          if(localStorage.getItem("fblogin")==null){
            this.djmenu.push({ title: 'Change Password', component: ChangepassworddjPage, icon: 'historical' });
          }          
          this.djmenu.push({ title: 'Sign Out', component: null, icon: 'log' });
          this.menuCtrl.enable(true, 'dj');
      }
    }
  })
  }
 
  initializeApp() {
    this.platform.ready().then(() => {
      //  this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.rootPage = SignindjPage;
      if (localStorage.getItem('role')!=null) { 
        if (localStorage.getItem('role') == 'clubgoer') {
          this.rootPage = localStorage.getItem("USER_DATA") != null ? HomePage : SignindjPage;
        } else {
          this.rootPage = localStorage.getItem("USER_DATA") != null ? EventsdjPage : SignindjPage;
          //this.rootPage = (JSON.parse(localStorage.getItem("USER_DATA")).subscription_status!=1) ? SubscribedjPage : localStorage.getItem("USER_DATA") != null ? EventsdjPage : SignindjPage;
        } 
      }
  if (localStorage.getItem("USER_DATA") != null) {
        this.profile = JSON.parse(localStorage.getItem("USER_DATA"));
      }
    });
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    if (page.component) {
      this.nav.setRoot(page.component);
      this.activePage = page;
    } else {
      if(localStorage.getItem('role')=="dj")
      {
        this.menuCtrl.enable(false, 'dj');
      } else {
        this.menuCtrl.enable(false, 'clubgoer');
      }
      localStorage.removeItem("fblogin");
      localStorage.removeItem("USER_DATA");
      localStorage.removeItem("facebook_pic");
      localStorage.removeItem("facebook_login");
      localStorage.removeItem("userid");
      localStorage.removeItem("fblogin");
      //localStorage.removeItem('role');
      //localStorage.clear();
      let alert = this.alertCtrl.create({
        title: 'Logged out',
        subTitle: "Logged out successfully",
      });
      alert.present();
      setTimeout(() => alert.dismiss(), 1000);
      if(localStorage.getItem('role')=="dj")
      {
        this.nav.setRoot(LogindjPage);
      } else {
        this.nav.setRoot(LoginPage);
      }
      
    }
  }
  public checkActivePage(page): boolean {
    return page === this.activePage;
  }
}
