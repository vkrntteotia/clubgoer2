import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EventsdjPage } from './eventsdj';

@NgModule({
  declarations: [
    EventsdjPage,
  ],
  imports: [
    IonicPageModule.forChild(EventsdjPage),
  ],
})
export class EventsdjPageModule {}
