import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Events } from 'ionic-angular';
import {AddeventdjPage} from '../addeventdj/addeventdj';
import {ManageeventsdjPage} from '../manageeventsdj/manageeventsdj';

/**
 * Generated class for the EventsdjPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-eventsdj',
  templateUrl: 'eventsdj.html',
})
export class EventsdjPage {
  profile;
  constructor(public navCtrl: NavController, public events: Events, public navParams: NavParams) {
    if (localStorage.getItem("USER_DATA")!=null) { 
      this.profile = JSON.parse(localStorage.getItem("USER_DATA"));
      if(this.profile.role == 'dj'){
        this.events.publish('role','dj');
      }else{
        this.events.publish('role','clubgoer');
      }
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EventsdjPage');
  }
  addEvent(){
    this.navCtrl.push(AddeventdjPage);
  }
  ManageEvent(){
    this.navCtrl.push(ManageeventsdjPage);
  }

}
