import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddeventdjPage } from './addeventdj';

@NgModule({
  declarations: [
    AddeventdjPage,
  ],
  imports: [
    IonicPageModule.forChild(AddeventdjPage),
  ],
})
export class AddeventdjPageModule {}
