import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ToastController,AlertController,ActionSheetController } from 'ionic-angular';
import { Camera, CameraOptions } from '@ionic-native/camera';
import {Http, Headers, RequestOptions} from '@angular/http';
import {LoadingController} from 'ionic-angular';
import { Appsetting } from '../../providers/appsetting';
import { EventsdjPage } from '../eventsdj/eventsdj';
/**
 * Generated class for the AddeventdjPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addeventdj',
  templateUrl: 'addeventdj.html',
})
export class AddeventdjPage {
  public userdata;
  public taggel=true;
  public imgTosend;
  public srcImage; 
  public data={};
  public minyear;
  
  constructor(public navCtrl: NavController,
    public navParams: NavParams, 
    public http: Http,
    private camera: Camera,
    public actionSheetCtrl: ActionSheetController,
    public loadingCtrl: LoadingController,
    public toastCtrl:ToastController,
    public appsetting: Appsetting,
    private alertCtrl: AlertController) {
      var d = new Date();
      this.minyear = d.getFullYear();
  }

  public Loader = this.loadingCtrl.create({
		content: 'Please wait...'
  });
  
  toggleDetails(taggel) {
    if (taggel) {
        this.taggel = false;
    } else {
        this.taggel = true;
    }
  }
  addevent(addevent){
    let headers = new Headers();
    headers.append('Content-Type',  'application/x-www-form-urlencoded;charset=utf-8');
    let options= new RequestOptions({ headers: headers });
    var user_id = JSON.parse(localStorage.getItem("USER_DATA")).id;
    var data = {
      user_id:user_id,
      venue_name:addevent.value.venuename,
      venue_addr:addevent.value.venueaddress,
      event_name:addevent.value.eventname,
      event_start_date : addevent.value.eventstartdt,
      event_end_date : addevent.value.eventenddt,
      event_start_time : addevent.value.eventsarttm,
      event_end_time : addevent.value.eventendtm,
      play_now_amt : addevent.value.minplay,
      guaranteed_play : addevent.value.mingrnt,
      possibly_play : addevent.value.minpossi,      
      image : this.imgTosend,
      role : 'dj'
    }
    this.Loader.present();
    var Serialized = this.serializeObj(data);
    this.http.post(this.appsetting.myGlobalVar + 'events/addevent', Serialized, options).map(res=>res.json()).subscribe(response=>{
      this.Loader.dismiss();
      if (response.status == 0) {
        console.log("vikkdisiods");
        let alert = this.alertCtrl.create({
          title: 'Add event',
          subTitle: response.msg,
        });
        alert.present();
        setTimeout(()=>alert.dismiss(),1500);
        this.navCtrl.push(EventsdjPage);
      } else {
        let alert = this.alertCtrl.create({
          title: 'Add event',
          subTitle: response.msg,
        });
        alert.present();
        setTimeout(()=>alert.dismiss(),1500);
      }
   })
  }

  serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));

    return result.join("&");
  }

  CameraAction() {
   let actionsheet = this.actionSheetCtrl.create({
     title: "Choose Album",
     buttons: [{
       text: 'Camera',
       handler: () => {
       //	this.Loader.present();
         const options: CameraOptions = {
           quality: 8,
           sourceType: 1,
           destinationType: this.camera.DestinationType.DATA_URL,
           encodingType: this.camera.EncodingType.JPEG,
           mediaType: this.camera.MediaType.PICTURE
         }
     this.camera.getPicture(options).then((imageUri) => {
           this.srcImage = 'data:image/jpeg;base64,' + imageUri;
           this.imgTosend = imageUri;
           this.Loader.dismiss();
           //this.changeimage();
         }, (err) => {
           // alert(JSON.stringify(err));
           this.Loader.dismiss();
           console.log(err);
         });
       }
     },
     {
       text: 'Gallery',
       handler: () => {
         const options: CameraOptions = {
           quality: 20,
           sourceType: 0,
           destinationType: this.camera.DestinationType.DATA_URL,
           encodingType: this.camera.EncodingType.JPEG,
           mediaType: this.camera.MediaType.PICTURE
         }

         this.camera.getPicture(options).then((imageData) => {
          this.srcImage = 'data:image/jpeg;base64,' + imageData;
         this.imgTosend = imageData;
         }, (err) => {
           this.Loader.dismiss();
         });
       }
     },
     {
       text: 'Cancel',
       role: 'cancel',
       handler: () => {
         console.log('Cancel clicked');
       }
     }]
   });
   actionsheet.present();
 }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddeventdjPage');
  }

}
