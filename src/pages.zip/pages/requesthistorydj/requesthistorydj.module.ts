import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RequesthistorydjPage } from './requesthistorydj';

@NgModule({
  declarations: [
    RequesthistorydjPage,
  ],
  imports: [
    IonicPageModule.forChild(RequesthistorydjPage),
  ],
})
export class RequesthistorydjPageModule {}
