import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PossiblydjPage } from './possiblydj';

@NgModule({
  declarations: [
    PossiblydjPage,
  ],
  imports: [
    IonicPageModule.forChild(PossiblydjPage),
  ],
})
export class PossiblydjPageModule {}
