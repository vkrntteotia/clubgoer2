import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfileeditPage } from './profileedit';

@NgModule({
  declarations: [
    ProfileeditPage,
  ],
  imports: [
    IonicPageModule.forChild(ProfileeditPage),
  ],
})
export class ProfileeditPageModule {}
