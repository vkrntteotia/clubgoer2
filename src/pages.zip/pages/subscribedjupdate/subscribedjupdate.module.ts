import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SubscribedjupdatePage } from './subscribedjupdate';

@NgModule({
  declarations: [
    SubscribedjupdatePage,
  ],
  imports: [
    IonicPageModule.forChild(SubscribedjupdatePage),
  ],
})
export class SubscribedjupdatePageModule {}
