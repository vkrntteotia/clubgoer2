import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TermsdjPage } from './termsdj';

@NgModule({
  declarations: [
    TermsdjPage,
  ],
  imports: [
    IonicPageModule.forChild(TermsdjPage),
  ],
})
export class TermsdjPageModule {}
