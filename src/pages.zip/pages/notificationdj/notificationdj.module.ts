import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NotificationdjPage } from './notificationdj';

@NgModule({
  declarations: [
    NotificationdjPage,
  ],
  imports: [
    IonicPageModule.forChild(NotificationdjPage),
  ],
})
export class NotificationdjPageModule {}
