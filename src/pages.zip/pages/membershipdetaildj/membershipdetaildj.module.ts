import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MembershipdetaildjPage } from './membershipdetaildj';

@NgModule({
  declarations: [
    MembershipdetaildjPage,
  ],
  imports: [
    IonicPageModule.forChild(MembershipdetaildjPage),
  ],
})
export class MembershipdetaildjPageModule {}
