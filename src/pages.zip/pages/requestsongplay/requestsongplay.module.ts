import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RequestsongplayPage } from './requestsongplay';

@NgModule({
  declarations: [
    RequestsongplayPage,
  ],
  imports: [
    IonicPageModule.forChild(RequestsongplayPage),
  ],
})
export class RequestsongplayPageModule {}
