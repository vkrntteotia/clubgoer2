import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LogindjPage } from './logindj';

@NgModule({
  declarations: [
    LogindjPage,
  ],
  imports: [
    IonicPageModule.forChild(LogindjPage),
  ],
})
export class LogindjPageModule {}
