import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PlaynowlistdjPage } from './playnowlistdj';

@NgModule({
  declarations: [
    PlaynowlistdjPage,
  ],
  imports: [
    IonicPageModule.forChild(PlaynowlistdjPage),
  ],
})
export class PlaynowlistdjPageModule {}
