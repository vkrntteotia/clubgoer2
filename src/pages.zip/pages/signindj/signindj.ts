import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SignupPage } from '../signup/signup';
import { SignupdjPage } from '../signupdj/signupdj';

/**
 * Generated class for the SignindjPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signindj',
  templateUrl: 'signindj.html',
})
export class SignindjPage {
  vid;
  video;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }
signup_clubgoer(){
    localStorage.setItem('role','clubgoer');
this.navCtrl.push(SignupPage);
}
playVideo(){
  
  this.vid="http://priyank.crystalbiltech.com/dj/files/djjvideo.mp4";
       this.video = document.getElementById("video-bg");
       this.video.src = this.vid; 
       this.video.muted = true; 
       this.video.loop = true;
      this.video.play();
      this.video.addEventListener('webkitendfullscreen', function (e) { 
        console.log("vikki");
        console.log(e);
        console.log("ramit");
        // handle end full screen 
      });
}
signup_dj(){
  localStorage.setItem('role','dj');
this.navCtrl.push(SignupdjPage);
}
  ionViewDidLoad() {
    console.log('ionViewDidLoad SignindjPage');
    this.playVideo();
  }
  
}
