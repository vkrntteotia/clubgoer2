import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignindjPage } from './signindj';

@NgModule({
  declarations: [
    SignindjPage,
  ],
  imports: [
    IonicPageModule.forChild(SignindjPage),
  ],
})
export class SignindjPageModule {}
