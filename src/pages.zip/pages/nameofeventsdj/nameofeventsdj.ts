import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,LoadingController} from 'ionic-angular';
import { PlaynowlistdjPage } from '../playnowlistdj/playnowlistdj';
import {Http, Headers, RequestOptions} from '@angular/http';
import { Appsetting } from '../../providers/appsetting';
import { TopqueuedjPage } from '../topqueuedj/topqueuedj';
import { GauranteedjPage } from '../gauranteedj/gauranteedj';
import { PossiblydjPage } from '../possiblydj/possiblydj';
/**
 * Generated class for the NameofeventsdjPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nameofeventsdj',
  templateUrl: 'nameofeventsdj.html',
})
export class NameofeventsdjPage {
  public playnow;
  public gauranteedplay;
  public possiblyplay;
  public topqueue;
  constructor(public navCtrl: NavController,
    public navParams: NavParams, 
    public http: Http,
    public appsetting: Appsetting,
    public loadingCtrl: LoadingController,) {
      this.requestinfo();
  }

  requestinfo(){
    let headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
    var options = new RequestOptions({ headers: headers });
    var Userid = JSON.parse(localStorage.getItem("USER_DATA")).id;
    let Loader = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    Loader.present().then(() => {
      var data = {
        djid: Userid,
            }
      var serialized = this.serializeObj(data);
      this.http.post(this.appsetting.myGlobalVar + 'events/requestcount', serialized, options)
        .map(res => res.json())
        .subscribe(data => {
          Loader.dismiss();
          if (data.isSucess == "true") {
            this.playnow=data.playnow;
            this.gauranteedplay=data.gauranteedplay;
            this.possiblyplay=data.possiblyplay;
            this.topqueue=data.topqueue;
          } else {
            
          }
        })
    });
  }

  serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));
        return result.join("&");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NameofeventsdjPage');  
  }

  topque(){
    this.navCtrl.push(TopqueuedjPage);
  }

  play() {
    this.navCtrl.push(PlaynowlistdjPage);
  }

  grntply(){
    this.navCtrl.push(GauranteedjPage);
  }

  possply(){
    this.navCtrl.push(PossiblydjPage);
  }

}
