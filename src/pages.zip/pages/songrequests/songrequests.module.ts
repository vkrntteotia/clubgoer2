import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SongrequestsPage } from './songrequests';

@NgModule({
  declarations: [
    SongrequestsPage,
  ],
  imports: [
    IonicPageModule.forChild(SongrequestsPage),
  ],
})
export class SongrequestsPageModule {}
