import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ManageeventsdjPage } from './manageeventsdj';

@NgModule({
  declarations: [
    ManageeventsdjPage,
  ],
  imports: [
    IonicPageModule.forChild(ManageeventsdjPage),
  ],
})
export class ManageeventsdjPageModule {}
