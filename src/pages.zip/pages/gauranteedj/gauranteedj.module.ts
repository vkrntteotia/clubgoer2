import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GauranteedjPage } from './gauranteedj';

@NgModule({
  declarations: [
    GauranteedjPage,
  ],
  imports: [
    IonicPageModule.forChild(GauranteedjPage),
  ],
})
export class GauranteedjPageModule {}
