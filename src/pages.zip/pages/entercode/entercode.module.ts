import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EntercodePage } from './entercode';

@NgModule({
  declarations: [
    EntercodePage,
  ],
  imports: [
    IonicPageModule.forChild(EntercodePage),
  ],
})
export class EntercodePageModule {}
