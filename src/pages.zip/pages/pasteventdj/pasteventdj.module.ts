import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PasteventdjPage } from './pasteventdj';

@NgModule({
  declarations: [
    PasteventdjPage,
  ],
  imports: [
    IonicPageModule.forChild(PasteventdjPage),
  ],
})
export class PasteventdjPageModule {}
