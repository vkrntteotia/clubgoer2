import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TermsdjsubsPage } from './termsdjsubs';

@NgModule({
  declarations: [
    TermsdjsubsPage,
  ],
  imports: [
    IonicPageModule.forChild(TermsdjsubsPage),
  ],
})
export class TermsdjsubsPageModule {}
