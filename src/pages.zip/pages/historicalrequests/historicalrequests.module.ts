import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HistoricalrequestsPage } from './historicalrequests';

@NgModule({
  declarations: [
    HistoricalrequestsPage,
  ],
  imports: [
    IonicPageModule.forChild(HistoricalrequestsPage),
  ],
})
export class HistoricalrequestsPageModule {}
