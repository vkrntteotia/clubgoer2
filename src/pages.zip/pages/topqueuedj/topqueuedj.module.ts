import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TopqueuedjPage } from './topqueuedj';

@NgModule({
  declarations: [
    TopqueuedjPage,
  ],
  imports: [
    IonicPageModule.forChild(TopqueuedjPage),
  ],
})
export class TopqueuedjPageModule {}
