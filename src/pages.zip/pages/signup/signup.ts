import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ToastController,AlertController,Events,Navbar } from 'ionic-angular';
import {Http, Headers, RequestOptions} from '@angular/http';
import { LoginPage } from '../login/login';
import { HomePage } from '../home/home';
import 'rxjs/add/operator/map';
import {LoadingController} from 'ionic-angular';
import { Appsetting } from '../../providers/appsetting';

/**
 * Generated class for the SignupPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {
public data='';id;
public Loading=this.loadingCtrl.create({
    content: 'Please wait...'
    
  });
  constructor(
   public navCtrl: NavController,
   public navParams: NavParams,
   public appsetting: Appsetting,
   public http:Http,
   public loadingCtrl:LoadingController,
   public toastCtrl:ToastController,
   private alertCtrl: AlertController,
    public events: Events,
    public navBar: Navbar
   ) {
     
     if(localStorage.getItem("USER_DATA")){
         this.navCtrl.push(HomePage);
    }
  }

ionViewDidEnter() {
    if (window.navigator.onLine == true) {
    } else {
      this.Loading.dismiss();
       let alert = this.alertCtrl.create({
        title: 'Network connection',
        subTitle: 'Something went wrong check your internet connection',
        });
       alert.present();
       setTimeout(()=>alert.dismiss(),1500);
      }
    }

    setBackButtonAction(){
      this.navBar.backButtonClick = () => {
      //Write here wherever you wanna do
         this.navCtrl.pop()
      }
   }
 public register(signup){
  
let headers = new Headers();
headers.append('Content-Type',  'application/x-www-form-urlencoded;charset=utf-8');
let options= new RequestOptions({ headers: headers });
 if (signup.value.password.indexOf(' ') >= 0) {
    let alert = this.alertCtrl.create({
            title: 'Signup',
            subTitle: "Space not allowed",
      });
          alert.present();
          setTimeout(()=>alert.dismiss(),1500);
  } else if(signup.value.password == signup.value.cpassword){
       this.Loading.present();
    var data ={
      name:signup.value.name,
      email:signup.value.email,
      password:signup.value.password,
      role:'clubgoer'
    }
    var Serialized = this.serializeObj(data);
      //console.log(data);
    this.http.post(this.appsetting.myGlobalVar + 'users/registration', Serialized, options).map(res=>res.json()).subscribe(response=>{
       // console.log(response);
    this.Loading.dismiss();
    if(response.isSuccess == true){
       this.events.publish('role', 'clubgoer');
      localStorage.setItem("USER_DATA", JSON.stringify(response.user_data));
    let alert = this.alertCtrl.create({
            title: 'Signup',
            subTitle: response.msg,
      });
          alert.present();
          setTimeout(()=>alert.dismiss(),1500);
    this.navCtrl.push(HomePage);
}else{
      let alert = this.alertCtrl.create({
            title: 'Signup',
            subTitle: response.msg,
      });
          alert.present();
          setTimeout(()=>alert.dismiss(),1500);
}
    })
  }else{
     let alert = this.alertCtrl.create({
            title: 'Signup',
            subTitle: 'Password did not match',
      });
          alert.present();
          setTimeout(()=>alert.dismiss(),1500);
    }
 }
   serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));

    return result.join("&");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupPage');
  }

signinPage(){
  this.navCtrl.push(LoginPage);
}
}

