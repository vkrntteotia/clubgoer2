import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChangepassworddjPage } from './changepassworddj';

@NgModule({
  declarations: [
    ChangepassworddjPage,
  ],
  imports: [
    IonicPageModule.forChild(ChangepassworddjPage),
  ],
})
export class ChangepassworddjPageModule {}
