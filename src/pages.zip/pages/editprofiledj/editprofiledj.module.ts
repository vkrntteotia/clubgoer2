import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditprofiledjPage } from './editprofiledj';

@NgModule({
  declarations: [
    EditprofiledjPage,
  ],
  imports: [
    IonicPageModule.forChild(EditprofiledjPage),
  ],
})
export class EditprofiledjPageModule {}
