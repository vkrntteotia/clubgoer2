import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController,AlertController } from 'ionic-angular';
import {Http, Headers, RequestOptions} from '@angular/http';
import { Appsetting } from '../../providers/appsetting';
import {LoadingController} from 'ionic-angular';
import {ProfilePage} from '../profile/profile';
import {HomePage} from '../home/home';
import { InAppBrowser } from '@ionic-native/in-app-browser';
/**
 * Generated class for the PayinfoPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-payinfo',
  templateUrl: 'payinfo.html',
})
export class PayinfoPage {
  public data = {}; minyear;maxyear;setbit;pdata;
  public Loading=this.loadingCtrl.create({
    content: 'Please wait...'
  });
  constructor(
   public navCtrl: NavController,
   public navParams: NavParams,
   public appsetting: Appsetting,
   public http:Http,
   public loadingCtrl:LoadingController,
   public toastCtrl:ToastController,
   private alertCtrl: AlertController,
   private iab: InAppBrowser
  ) {
    var d = new Date();
    this.minyear = d.getFullYear();
    this.maxyear = this.minyear+20;
    this.data={'relationship':2};
    this.setbit=0;
    this.pdata = navParams.get("postdata");
   //console.log(this.pdata);
   // this.checkpayinfo(this.pdata.userid);
  }
//   checkpayinfo(userid){
//     let headers = new Headers();
//     headers.append('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
//     let options= new RequestOptions({ headers: headers });
//       var data ={
//             userid:userid
//           }
//  var Serialized = this.serializeObj(data);
//         this.http.post(this.appsetting.myGlobalVar + 'users/checkpayinfo', Serialized, options).map(res=>res.json()).subscribe(response=>{
//      this.Loading.dismiss(); 
//               if(response.isSuccess == true){
//                 if(response.data!=null){
//                 this.data={'relationship':1,
//                            'name':response.data.name,
//                            'cardnum':response.data.cardnumber,
//                            'monyear':response.data.expiry,
//                            'cvv':response.data.cvv};
//                 }
//               }else{
//                   let alert = this.alertCtrl.create({
//                   title: 'Edit payment info',
//                   subTitle: response.msg,
//                 });
//                 alert.present();
//                 setTimeout(()=>alert.dismiss(),1500);
//               }
//     })
//   }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PayinfoPage');
  }
  setbitnow(bitnow){
    //this.setbit=bitnow;
    var target = "_blank";    
    var options = "location=no,hidden=no";
    var browser = this.iab.create('http://priyank.crystalbiltech.com/paypal-adaptive/chained-payment/proccess.php?data='+encodeURIComponent(JSON.stringify(this.pdata)),target,options);
    browser.on('loadstart').subscribe((e) => {
      //  alert(e)
        //console.log(e);
        let url = e.url;
        //console.log(url);

        var redirect_uri = e.url.split('code=');
        //console.log(redirect_uri);
      //  alert(redirect_uri[0]);
        if (redirect_uri[0] == 'https://priyank.crystalbiltech.com/?') {
        //  alert('code--->' + code);
          browser.close();
          this.navCtrl.push(HomePage);
          let alert = this.alertCtrl.create({
                title: 'Payment info',
                subTitle: "Payment done successfully"
                });
                alert.present();
                setTimeout(()=>alert.dismiss(),1500);
        }
      }, err => {
        //console.log("InAppBrowser loadstart Event Error: " + err);
       // alert(err)
      });
}
paynow(payinfo){
  this.Loading.present();
  var user_id = JSON.parse(localStorage.getItem("USER_DATA")).id;
  let headers = new Headers();
  headers.append('Content-Type',  'application/x-www-form-urlencoded;charset=utf-8');
  let options= new RequestOptions({ headers: headers });
if(payinfo.value.relationship==undefined){
          let alert = this.alertCtrl.create({
                title: 'Edit payment info',
                subTitle: "Please select payment method"
                });
                alert.present();
                setTimeout(()=>alert.dismiss(),1500);
                  this.Loading.dismiss();
} else{
var data ={
    id:user_id,
    cardnum:payinfo.value.cardnum,
    monyear:payinfo.value.monyear,
    name:payinfo.value.name,
    method:payinfo.value.relationship,
    cvv:payinfo.value.cvv
  }
 }
}
ionViewDidEnter() {
    if (window.navigator.onLine == true) {
    } else {
      this.Loading.dismiss();
       let alert = this.alertCtrl.create({
        title: 'Network connection',
        subTitle: 'Something went wrong check your internet connection',
        });
       alert.present();
       setTimeout(()=>alert.dismiss(),1500);
      }
    }
serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));

    return result.join("&");
  }
}
