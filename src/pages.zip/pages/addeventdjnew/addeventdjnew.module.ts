import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddeventdjnewPage } from './addeventdjnew';

@NgModule({
  declarations: [
    AddeventdjnewPage,
  ],
  imports: [
    IonicPageModule.forChild(AddeventdjnewPage),
  ],
})
export class AddeventdjnewPageModule {}
