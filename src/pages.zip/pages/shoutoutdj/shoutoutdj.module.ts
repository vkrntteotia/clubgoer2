import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ShoutoutdjPage } from './shoutoutdj';

@NgModule({
  declarations: [
    ShoutoutdjPage,
  ],
  imports: [
    IonicPageModule.forChild(ShoutoutdjPage),
  ],
})
export class ShoutoutdjPageModule {}
