import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HelpdjPage } from './helpdj';

@NgModule({
  declarations: [
    HelpdjPage,
  ],
  imports: [
    IonicPageModule.forChild(HelpdjPage),
  ],
})
export class HelpdjPageModule {}
