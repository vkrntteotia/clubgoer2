import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {Http, Headers, RequestOptions} from '@angular/http';
import { Appsetting } from '../../providers/appsetting';
import { Stripe } from '@ionic-native/stripe';

/**
 * Generated class for the AddCardPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-card',
  templateUrl: 'add-card.html',
})
export class AddCardPage {
public card:any = [];
  constructor(public navCtrl: NavController, public navParams: NavParams, public http:Http,
    public appsetting: Appsetting,private stripe: Stripe) {
     
  }
  
  private add_card(formdata){
      console.log(formdata.value);
       let headers = new Headers();
  headers.append('Content-Type',  'application/x-www-form-urlencoded;charset=utf-8');
  let options= new RequestOptions({ headers: headers });
  var email = JSON.parse(localStorage.getItem("USER_DATA")).email;
  this.stripe.setPublishableKey('pk_test_gGw0nKJtPn2n9zGD1JuR7iV6');
var cardno;
if(formdata.value.mmyy && formdata.value.cardnumber){
    var a = formdata.value.mmyy.split('/');
    console.log(a);
    var b = formdata.value.cardnumber.split('-');
    console.log(b);
    cardno = b[0]+b[1]+b[2]+b[3];
    console.log(cardno);
}
let card = {
 number: cardno,
 expMonth: parseInt(a[0]),
 expYear: parseInt(a[1]),
 cvc: formdata.value.cvc,
 name:formdata.value.name,
 address_line1:formdata.value.address,
 address_city:formdata.value.city,
 address_state:formdata.value.state,
 postal_code:formdata.value.zip
};
console.log(card);
this.stripe.createCardToken(card)
   .then(token => {
   console.log(token.id);
   alert('success');
   alert(token.id);
   
   })
   .catch(error => {
   console.error(error);
   alert(JSON.stringify(error));
   
   });
   
   
   
//  var data ={
//    email:email,
//    price:this.navParams.get('amount'),
//    cardnumber:formdata.value.cardnumber,
//    address:formdata.value.address,
//    city:formdata.value.city,
//    contact:formdata.value.contact,
//    mmyy:formdata.value.mmyy,
//    name:formdata.value.name,
//    state:formdata.value.state,
//    username:formdata.value.username,
//    zip:formdata.value.zip,
//    }
//  var Serialized = this.serializeObj(data);
//  this.http.post(this.appsetting.myGlobalVar + 'subscriptions/stripe', Serialized, options).map(res=>res.json()).subscribe(response=>{
//     console.log(response);
//        
//    })
  }

  
  
   cardFormat(number) {
    console.log(number);
    if (number.length == 4) {
      this.card.cardnumber = number + '-';

    } else if (number.length == 9) {
      this.card.cardnumber = number + '-';
    }else if (number.length == 14) {
      this.card.cardnumber = number + '-';
    }
  }
  dateFormat(date){
  console.log(date);
  if(date.length == 2){
      this.card.mmyy = date+'/';
    }
}
contactFormat(number){
  console.log(number);
  if(number.length == 3){
      this.card.contact = number+'-'
  } else if (number.length == 7){
      this.card.contact = number+'-';
  }
}
 serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));

    return result.join("&");
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AddCardPage');
  }

}
